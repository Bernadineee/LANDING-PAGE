export { default as logo } from './logo.svg';
export { default as mockups } from './illustration-mockups.svg';
